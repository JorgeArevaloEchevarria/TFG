Directorio pensado para guardar las "fuentes" de las imágenes (archivos de Photoshop, Visio, Gimp, etc., antes de pasarlas a los formatos que usa LaTeX)
